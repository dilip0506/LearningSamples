﻿namespace After032_PortableClassLibrary
{
    public static class Greeter
    {
        public static string Greet(string name)
        {
            return "Hello " + name;
        }
    }
}
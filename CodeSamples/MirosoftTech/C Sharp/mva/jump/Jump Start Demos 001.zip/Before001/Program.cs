﻿namespace Before001
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}
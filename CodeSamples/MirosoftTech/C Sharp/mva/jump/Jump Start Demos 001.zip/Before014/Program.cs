﻿namespace Before014
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var csv = "FirstName,LastName,Company,Address,City,County,State,ZIP,Phone,Fax,Email,Web\r\n"
                      +
                      "Essie,Vaill,Litronic Industries,14225 Hancock Dr,Anchorage,Anchorage,AK,99515,907-345-0962,907-345-1215,essie@vaill.com,http://www.essievaill.com\r\n"
                      +
                      "Cruz,Roudabush,Meridian Products,2202 S Central Ave,Phoenix,Maricopa,AZ,85004,602-252-4827,602-252-4009,cruz@roudabush.com,http://www.cruzroudabush.com\r\n"
                      +
                      "Billie,Tinnes,D & M Plywood Inc,28 W 27th St,New York,New York,NY,10001,212-889-5775,212-889-5764,billie@tinnes.com,http://www.billietinnes.com\r\n"
                      +
                      "Zackary,Mockus,Metropolitan Elevator Co,286 State St,Perth Amboy,Middlesex,NJ,08861,732-442-0638,732-442-5218,zackary@mockus.com,http://www.zackarymockus.com\r\n"
                      +
                      "Rosemarie,Fifield,Technology Services,3131 N Nimitz Hwy  #-105,Honolulu,Honolulu,HI,96819,808-836-8966,808-836-6008,rosemarie@fifield.com,http://www.rosemariefifield.com\r\n";

            // split into lines

            // split line into fields

            // create a pipe "|" delimited string instead

        }
    }
}
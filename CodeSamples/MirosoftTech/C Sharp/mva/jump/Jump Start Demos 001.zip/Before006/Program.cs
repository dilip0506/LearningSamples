﻿namespace Before006
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var strings = new[] {"String 1", "String 2", "String 3"};

            // how can I iterate through the string array?

            // crazy!

            // easier

            // easy!
        }
    }
}
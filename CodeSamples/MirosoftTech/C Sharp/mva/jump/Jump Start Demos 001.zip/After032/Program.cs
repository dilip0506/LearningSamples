﻿namespace After032
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}
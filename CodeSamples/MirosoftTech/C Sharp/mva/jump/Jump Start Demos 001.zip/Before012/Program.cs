﻿namespace Before012
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // create a stringbuilder instance

            // append lines

            // append formatted values

            // replace values

            // insert 

            // remove

            // convert to a string

            // convert a subset to a string
        }
    }
}
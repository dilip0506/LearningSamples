﻿namespace Before010
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] array = { 3, 2, 5, 1, 4, 10, 7, 6, 9, 8 };

            // loop through array until you find 6: for

            // loop through array until you find 6: foreach

            // skip processing for ever 2nd item in the array : for

            // skip processing if item is 3 : foreach

           // demo while

            // demo do

            // demo yield

            // using yield return and yield break to fill a list
        }
    }

    internal class AnimalCollection 
    {
        private IAnimal[] _animals = { new Monkey(), new Dog(), new Monkey(), new Dog(), new Dog() };

    }
}
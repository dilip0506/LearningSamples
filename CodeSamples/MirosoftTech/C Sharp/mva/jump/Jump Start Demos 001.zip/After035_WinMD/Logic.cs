﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace After035_WinMD
{
    public sealed class Logic
    {
        public static double Add(double val1, double val2)
        {
            return val1 + val2;
        }
    }
}

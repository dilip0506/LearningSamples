﻿namespace Before008
{
    internal static class Logger
    {
        internal static void Log(LogLevel level, string message)
        {
        }
    }
}